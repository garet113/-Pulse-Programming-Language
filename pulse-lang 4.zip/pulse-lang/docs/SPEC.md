# Pulse Language Specification (v0)

Pulse is **reactive-by-default** and **time-native**.

## Core Concepts
- **Signals**: `let x = expr` defines a live value which recomputes when its dependencies change.
- **Constants**: `const X = expr` defines a non-reactive constant.
- **Time blocks**: `@rate`, `@every`, `@after`, `@when`.
- **Previous value**: `~x` references the previous stable value of `x`.

## Types
Scalars: `Int`, `Float`, `Bool`, `String`, `Time`  
Collections: `List<T>`, `Map<K,V>`  
Special: `Signal<T>`

## Syntax (EBNF excerpt)
```
program     = { item } ;
item        = decl | stmt | timed_block ;
decl        = const_decl | let_decl ;
const_decl  = "const" IDENT "=" expr ;
let_decl    = "let" IDENT "=" expr ;

timed_block = rate_block | after_block | every_block | when_block ;
rate_block  = "@rate" freq ":" block ;
after_block = "@after" duration ":" block ;
every_block = "@every" duration ":" block ;
when_block  = "@when" IDENT [ "(" IDENT ")" ] ":" block ;

stmt        = assign | expr_stmt | emit_stmt ;
assign      = IDENT "=" expr ;
emit_stmt   = "emit" IDENT "(" [expr] ")" ;
expr_stmt   = expr ;

expr        = unary { ("*"|"/"|"%") unary | ("+"|"-") unary } ;
unary       = ("-"|"~") unary | call ;
call        = primary { "(" [args] ")" | "." IDENT } ;
primary     = NUMBER | STRING | "true" | "false" | IDENT | "(" expr ")" ;
```

## Semantics
- The runtime maintains a dependency graph of signals.
- When any signal changes, dependents recompute in topological order.
- Timed blocks are scheduled by a small cooperative scheduler.
- `emit name(payload)` invokes handlers registered with `@when name(payload)`.

## Stdlib (subset)
- Math: `sin(x)`, `clamp(x,a,b)`
- Signals: `smooth(sig, τ)` (demo placeholder)
- IO: `sensor(name)`, `actuator(name, val?)`, `print(...)`
- Time helpers: `now()`, `Hz(n)`, `s(n)`, `ms(n)`

See `pulse.py` for exact v0 behavior.
