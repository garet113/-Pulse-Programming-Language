# Pulse Roadmap

## v0 (this repo)
- Interpreter in Python
- Reactive signals, events, and time blocks
- Previous-value operator `~`
- Minimal stdlib

## v0.2
- `match` expressions
- Proper smoothing/filtering ops (EMA, debounce, fold)

## v0.5
- Bytecode VM, topological scheduler & incremental recompute
- Module system
- Better error messages

## v0.8
- Static type checker (H-M style) and ADTs
- Async IO (sockets, files)

## v1.0
- WASM backend
- Visual timeline IDE prototype
