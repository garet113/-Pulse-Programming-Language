# 🧠 Pulse Programming Language

**Pulse** is a new experimental **time-aware, reactive-by-default** programming language.  
Instead of waiting for inputs, Pulse variables *live and breathe* — they automatically update when their dependencies change.

> 🪄 Never-before-combined design: reactive dataflow + built-in time semantics.

---

## ✨ Core Features

- **Reactive by default:** every variable is a live signal.
- **Time primitives:** `@rate`, `@every`, `@after`, and `@when`.
- **Previous state:** use `~x` to reference the last value of `x`.
- **Events:** `emit event(payload)` and `@when event(payload): { ... }`.
- **Tiny runtime:** only ~500 lines of Python.

---

## 🚀 Quick Start

### 1️⃣ Clone (after you push this repo to GitHub)

```bash
git clone https://github.com/YOUR_USERNAME/pulse-lang.git
cd pulse-lang
```

### 2️⃣ Run the example

```bash
python3 pulse.py example.pulse
```

### 3️⃣ Output (example)

```
comfort: 20.45 temp: 21.0 ΔT: 0.5 led: 255
comfort: 20.60 temp: 21.5 ΔT: 0.5 led: 254
threshold event payload: 20.85
```

---

## 🧩 Example Code

```pulse
const TWO = 2
let temp = sensor("temp")
let hum  = sensor("humidity")
let comfort = smooth((temp * 0.7) + (hum * 0.3), 3)
let delta_temp = temp - ~temp
let wave = sin(now() * TWO * 3.14159)
let led  = clamp((wave + 1) * 128, 0, 255)

@rate 2Hz: {
  print("comfort:", comfort, "temp:", temp, "ΔT:", delta_temp, "led:", led)
}

@every 1s: {
  temp = temp + 0.5
}

@after 5s: {
  emit threshold(comfort)
}

@when threshold(payload): {
  print("threshold event payload:", payload)
}
```

---

## 📚 Docs

- [`docs/SPEC.md`](docs/SPEC.md): syntax and grammar
- [`docs/ROADMAP.md`](docs/ROADMAP.md): planned features and design goals

---

## 🧪 Tests

Run them manually, e.g.:

```bash
python3 pulse.py tests/test_reactivity.pulse
```

---

## 📜 License

MIT License © 2025 Garet Johnathan Palmer
